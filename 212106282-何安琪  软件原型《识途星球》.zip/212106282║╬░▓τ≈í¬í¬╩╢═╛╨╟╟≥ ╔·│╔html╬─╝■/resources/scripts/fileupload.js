var oldImg = $("[data-label='img'] img").attr("src")
function upload(file) {
    if (!file) {
        $("[data-label='img'] img").attr("src", oldImg);
        return;
    }
    var fr = new FileReader();
    fr.readAsDataURL(file);
    fr.onload = function () {
        $("[data-label='img'] img").attr("src", this.result);
    }
};
$("[data-label='fileupload'] input").change(function () {
    upload(this.files[0]);
});
$("[data-label='img'] img").click(function () {
    $("[data-label='fileupload'] input").click();
})